function showInfo(id) {
  const info = document.getElementById(id);
  info.style.display = (info.style.display === "block") ? "none" : "block";
}
